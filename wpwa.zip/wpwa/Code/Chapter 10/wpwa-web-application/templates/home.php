<?php get_header(); ?>
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Home Widgets') ) : endif; ?>
<?php get_footer(); ?>
