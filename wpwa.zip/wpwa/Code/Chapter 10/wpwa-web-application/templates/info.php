<?php get_header(); ?>

<div id="custom_panel">
<div id='info_message'>
	<?php echo esc_html($data['message']); ?>
</div>
</div>

<?php get_footer(); ?>
