<?php get_header(); ?>

<div id='custom_panel'>
    <div id='info_message'>
        <?php echo $message; ?>
    </div>
</div>

<?php get_footer(); ?>
